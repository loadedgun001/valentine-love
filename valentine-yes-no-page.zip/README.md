# Valentine's Day Website 💖

A beautiful, interactive Valentine's Day proposal website with animated hearts and playful buttons.

## Features

- ❤️ **Animated floating hearts** that float across the screen
- 💓 **Beating heart animation** with realistic heartbeat effect
- 🎯 **Interactive buttons**:
  - "YES!" button reveals a heartfelt message and creates a celebration of hearts
  - "No" button playfully moves away when you try to click it (perfect for touchscreens)
- 📱 **Fully responsive design** that works perfectly on iPhone, iPad, and desktop
- 🎨 **Beautiful gradient background** with romantic pink tones
- ✨ **Smooth animations** and transitions

## How to Host on GitHub (MacBook Instructions)

### Method 1: Using GitHub Website (Easiest)

1. **Create a GitHub account** at [github.com](https://github.com) if you don't have one
2. **Create a new repository**:
   - Click the "+" icon in the top-right corner
   - Select "New repository"
   - Name it (e.g., `valentine-website`)
   - Choose "Public"
   - Click "Create repository"

3. **Upload your files**:
   - On the new repository page, click "uploading an existing file"
   - Drag and drop the `index.html` file into the upload area
   - Click "Commit changes"

4. **Enable GitHub Pages**:
   - Go to your repository's **Settings**
   - Click **Pages** in the left sidebar
   - Under "Source", select "Deploy from a branch"
   - Choose the "main" branch and "/ (root)" folder
   - Click **Save**

5. **Wait for deployment** (usually 1-2 minutes)
6. **Visit your live site** at: `https://[your-username].github.io/[repository-name]/`

### Method 2: Using GitHub Desktop

1. Download and install [GitHub Desktop](https://desktop.github.com/)
2. Sign in with your GitHub account
3. Create a new repository in GitHub Desktop
4. Copy the `index.html` file into the repository folder
5. Commit and push to GitHub
6. Enable GitHub Pages as described above

### Method 3: Using Terminal (Advanced)

```bash
# Clone your repository (after creating it on github.com)
git clone https://github.com/your-username/valentine-website.git
cd valentine-website

# Copy index.html into the folder
# (Assuming it's in your Downloads folder)
cp ~/Downloads/index.html .

# Add, commit, and push
git add index.html
git commit -m "Add Valentine's Day website"
git push origin main
```

Then enable GitHub Pages via the website settings.

## Customization Tips

Want to personalize the website? You can edit the `index.html` file:

1. **Change the names/messages**: Look for text like "Will you be my Valentine?" and "Thank you for saying YES!"
2. **Modify colors**: Find color codes like `#e63946` (red) and `#f9c5d1` (pink) in the `<style>` section
3. **Add your own photos**: You could add an `<img>` tag with your favorite picture
4. **Change fonts**: The fonts are loaded from Google Fonts - you can choose different ones

## How the Website Works

- The "No" button uses JavaScript to detect mouse/touch movement and reposition itself
- When "YES!" is clicked, 50 celebration hearts are created with random positions and sizes
- The page is optimized for touchscreens with large, easy-to-tap buttons
- All animations use CSS for smooth performance

## Support

If you have any issues hosting the website, check out:
- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [GitHub Community Forum](https://github.com/community)

Made with ❤️ for someone special. Good luck with your Valentine's Day proposal!